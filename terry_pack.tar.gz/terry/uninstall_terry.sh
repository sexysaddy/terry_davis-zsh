#!/bin/bash

# Цвета для терминала
GREEN='\e[32m'
YELLOW='\e[1;33m'
NC='\e[0m'

echo -e "${YELLOW}🚨 Начинаем удаление святилища Терри Дэвиса...${NC}"

# 1. Удаляем скрытую папку со всеми файлами (скрипт, фото, цитаты)
DIR="$HOME/.terry"
if [ -d "$DIR" ]; then
    rm -rf "$DIR"
    echo -e "${GREEN}[+] Папка $DIR и все файлы внутри успешно удалены.${NC}"
else
    echo -e "${YELLOW}[!] Папка $DIR не найдена.${NC}"
fi

# 2. Функция для очистки файлов конфигурации оболочек
cleanup_rc() {
    local rc_file="$1"
    if [ -f "$rc_file" ]; then
        # Удаляем строчку вызова скрипта и сопутствующий комментарий
        # sed -i удаляет строки, содержащие указанный текст
        sed -i '/# Терри Дэвис на старте/d' "$rc_file"
        sed -i '\|\~\/\.terry\/welcome\.sh|d' "$rc_file"
        echo -e "${GREEN}[+] Записи автозапуска успешно вычищены из $rc_file.${NC}"
    fi
}

# Чистим конфиги zsh и bash
cleanup_rc "$HOME/.zshrc"
cleanup_rc "$HOME/.bashrc"

echo -e "${GREEN}✨ Очистка завершена! Терминал возвращен к стандартному виду.${NC}"
