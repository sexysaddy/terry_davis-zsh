#!/bin/bash

DIR="$HOME/.terry"

# 1. Вывод случайного фото через протокол Kitty
if [ -d "$DIR" ]; then
    RANDOM_IMG=$(find "$DIR" -type f \( -name "*.png" -o -name "*.jpg" -o -name "*.jpeg" \) | shuf -n 1)
    
    if [ ! -z "$RANDOM_IMG" ]; then
        kitten icat --stdin=no --align=left --fit=width --place=30x10@0x0 "$RANDOM_IMG"
        
        # Делаем жесткий отступ вниз на высоту картинки (11 пустых строк),
        # чтобы Powerlevel10k не накладывался поверх лица Терри
        for i in {1..11}; do echo ""; done
    fi
fi

# 2. Вывод случайной цитаты золотым цветом TempleOS
if [ -f "$DIR/quotes.txt" ]; then
    QUOTE=$(shuf -n 1 "$DIR/quotes.txt")
    echo -e "\e[1;33mTerry Davis says:\e[0m"
    echo -e "\e[32m$QUOTE\e[0m"
    echo ""
fi
