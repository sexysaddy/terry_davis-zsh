#!/bin/bash

GREEN='\e[32m'
YELLOW='\e[1;33m'
NC='\e[0m'

# Целевая папка в системе ВСЕГДА должна быть с точкой, чтобы пути в .zshrc не ломались
TARGET_DIR="$HOME/.terry"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE}")" && pwd)"

echo -e "${YELLOW}✝️ Начинаем установку святилища Терри Дэвиса...${NC}"

# Создаем системную скрытую папку, если её нет
mkdir -p "$TARGET_DIR"

# Копируем всё содержимое из текущей папки (как бы она ни называлась) в системную ~/.terry
echo -e "${YELLOW}[*] Копируем картинки и скрипты в системный каталог $TARGET_DIR...${NC}"
cp -r "$SCRIPT_DIR"/* "$TARGET_DIR/"

# Даем права на исполнение в системной папке
chmod +x "$TARGET_DIR/welcome.sh"
chmod +x "$TARGET_DIR/install_terry.sh"
chmod +x "$TARGET_DIR/uninstall_terry.sh"
echo -e "${GREEN}[+] Файлы скопированы, права доступа настроены.${NC}"

# Функция настройки автозапуска
inject_to_rc() {
    local rc_file="$1"
    if [ -f "$rc_file" ]; then
        if ! grep -q "~/.terry/welcome.sh" "$rc_file"; then
            if [[ "$rc_file" == *".zshrc"* ]]; then
                sed -i '1s|^|# Терри Дэвис на старте\n~/.terry/welcome.sh\n\n|' "$rc_file"
            else
                echo -e "\n# Терри Дэвис на старте\n~/.terry/welcome.sh" >> "$rc_file"
            fi
            echo -e "${GREEN}[+] Автозапуск успешно добавлен в $rc_file.${NC}"
        else
            echo -e "${YELLOW}[!] Автозапуск уже прописан в $rc_file.${NC}"
        fi
    fi
}

inject_to_rc "$HOME/.zshrc"
inject_to_rc "$HOME/.bashrc"

echo -e "${GREEN}✝️ Установка полностью завершена! Перезапусти Kitty для проверки.${NC}"
